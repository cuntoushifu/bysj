package life.majiang.community.enums;


public enum AdPosEnum {
    NAV, SIDE, FOOTER, HEADER
}
