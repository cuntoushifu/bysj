package life.majiang.community.enums;


public enum SortEnum {
    HOT,
    HOT30,
    HOT7,
    NO,
    NEW;
}
