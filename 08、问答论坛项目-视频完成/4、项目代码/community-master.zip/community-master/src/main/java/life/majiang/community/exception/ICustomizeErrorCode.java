package life.majiang.community.exception;


public interface ICustomizeErrorCode {
    String getMessage() ;
    Integer getCode();
}
